"""Lancement d'une suite décrite en JSON : python -m clusterprep suite.json."""

import argparse
from dataclasses import replace
import json
import sys
from pathlib import Path
from .io import get_data_info_dict, CLASS_NAMES


def preprocessing_main(argv):
    from .processed import prepare_processed

    parser = argparse.ArgumentParser(
        description="Préparer les FITS sans entraîner de modèle"
    )
    parser.add_argument("data_dir", type=Path)
    parser.add_argument("--processed-dir", type=Path, default=Path("processed"))
    parser.add_argument(
        "--mode", choices=("raw", "pair", "multimodal"), default="multimodal"
    )
    parser.add_argument("--size", type=int, default=128)
    parser.add_argument("--legacy-root", type=Path)
    parser.add_argument("--legacy-only", action="store_true", help="Prepare only optical products")
    parser.add_argument("--legacy-bands", nargs="+", default=["g", "r", "z"])
    parser.add_argument("--class-names", nargs="+", default=list(CLASS_NAMES))
    parser.add_argument(
        "--force", action="store_true", help="Recalculer même les FITS valides"
    )
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args(argv)
    if args.size < 1:
        parser.error("--size doit être positif")
    info = get_data_info_dict(args.data_dir, args.class_names)
    if args.legacy_only:
        if args.legacy_root is None:
            parser.error("--legacy-only requires --legacy-root")
        from .io import discover_legacy
        from .processed import load_processed_optical
        info = discover_legacy(info, args.legacy_root)
        counts = {"created": 0, "rebuilt": 0, "reused": 0, "absent": 0}
        for item in info.values():
            if not item.get("legacy_path"):
                counts["absent"] += 1
                continue
            _, status = load_processed_optical(item, args.size, args.processed_dir,
                                              bands=args.legacy_bands, force=args.force, return_status=True)
            counts[status] += 1
        print(json.dumps(counts, indent=2))
        return
    keys = [
        k for k, item in info.items() if args.mode != "pair" or item.get("chandra_path")
    ]
    counts = prepare_processed(
        info,
        keys,
        args.mode,
        args.size,
        args.processed_dir,
        verbose=not args.quiet,
        force=args.force,
    )
    print(json.dumps(counts, indent=2))


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] == "createconfig":
        from .config_wizard import create_config

        parser = argparse.ArgumentParser(
            description="Créer une configuration d'entraînement interactivement"
        )
        parser.add_argument("--output", type=Path, help="Fichier JSON à créer")
        args = parser.parse_args(argv[1:])
        create_config(args.output)
        return
    if argv and argv[0] == "preprocess":
        preprocessing_main(argv[1:])
        return
    from .training import ExperimentConfig, run_experiments, compare_experiments
    from .models import list_models

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("config", type=Path, nargs="?")
    parser.add_argument(
        "--list-models", action="store_true", help="Afficher les modèles disponibles"
    )
    parser.add_argument(
        "--quiet", action="store_true", help="Masquer les barres et résumés"
    )
    parser.add_argument(
        "--processed-dir", type=Path, help="Dossier commun des FITS prétraités"
    )
    args = parser.parse_args(argv)
    if args.list_models:
        print(json.dumps(list_models(), indent=2))
        return
    if args.config is None:
        parser.error("Un fichier de configuration est requis")
    spec = json.loads(args.config.read_text())
    classes = spec.get("class_names")
    configs = [ExperimentConfig(**item) for item in spec["experiments"]]
    # Historical binary JSONs commonly restrict discovery to DE/NDE folders.
    # Subtype tasks need the original annotations, including candidate folders.
    from .labels import SUBTYPE_TASKS
    discovery_classes = classes
    if any(c.task in SUBTYPE_TASKS for c in configs) and (classes is None or set(classes) == {"DE", "NDE"}):
        discovery_classes = None
    info = get_data_info_dict(spec["data_dir"], discovery_classes)
    if args.quiet:
        configs = [replace(c, verbose=False) for c in configs]
    if args.processed_dir is not None:
        configs = [replace(c, processed_dir=str(args.processed_dir)) for c in configs]
    if not configs:
        parser.error("La suite doit contenir au moins une expérience")
    output = Path(spec.get("output_dir", "results/experiments"))
    runs = run_experiments(
        info,
        configs,
        output,
        class_names=classes or CLASS_NAMES,
        **spec.get("split", {}),
    )
    # Le fichier de comparaison appartient à cette suite et ne remplace pas une autre.
    table = output / f"comparison-{runs[0].name}.csv"
    default_cohort = "paired" if any(c.mode == "pair" for c in configs) else "all"
    tables = []
    cohort = spec.get("comparison_cohort", default_cohort)
    populations = {}
    for run, c in zip(runs, configs):
        if not (run / "metrics.json").is_file():
            continue  # CV-only search has no test metrics.
        metrics = json.loads((run / "metrics.json").read_text())
        if not metrics.get("test_cohorts"):
            continue
        identity = metrics["test_cohorts"][cohort]["cohort_id"]
        populations.setdefault((c.task, identity), []).append(run)
    if len(populations) == 1:
        compare_experiments(
            runs, table, cohort=spec.get("comparison_cohort", default_cohort)
        )
        tables.append(table)
    else:
        for index, ((task, _), population) in enumerate(populations.items(), 1):
            task_table = table.with_name(table.stem + f"-{task}-{index}.csv")
            tables.append(task_table)
            compare_experiments(
                population,
                task_table,
                cohort=spec.get("comparison_cohort", default_cohort),
            )
        table = None
    print(
        json.dumps(
            {
                "runs": list(map(str, runs)),
                "comparison": str(table) if table else None,
                "comparisons": list(map(str, tables)),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
